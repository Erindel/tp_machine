# TP Machine Datapack

Server-side teleport selector datapack.
Rotation-safe, multiplayer-ready, no client mods required.

Minecraft Java 1.20.x
